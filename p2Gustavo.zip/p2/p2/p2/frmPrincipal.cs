﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p2
{
    public partial class frmPrincipal : Form
    {
        private string usuarioLogado;
        public frmPrincipal()
        {
            InitializeComponent();
            usuarioLogado = usuarioLogado;
        }

        private void btnCadUsu_Click(object sender, EventArgs e)
        {
            frmCadUsu cadUsu = new frmCadUsu(usuarioLogado);
            cadUsu.Show();
            this.Hide();
        }

        private void btnCadProduto_Click(object sender, EventArgs e)
        {
            frmProdutos produtos = new frmProdutos();
            produtos.Show();
            this.Hide();
        }

        private void btnCadCliente_Click(object sender, EventArgs e)
        {
            frmCliente cliente = new frmCliente();
            cliente.Show();
            this.Hide();
        }

        private void btnCadPed_Click(object sender, EventArgs e)
        {
            frmCadPedido cadPedido = new frmCadPedido();
            cadPedido.Show();
            this.Hide();
        }
    }
}
