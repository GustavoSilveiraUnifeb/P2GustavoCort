﻿namespace p2
{
    partial class frmProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNomeProd = new TextBox();
            txtPrecoProd = new TextBox();
            txtDescricaoProd = new TextBox();
            dgvProd = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            btnCadastrar = new Button();
            btnAtualizar = new Button();
            btnExcluir = new Button();
            btnListar = new Button();
            btnLimparCamp = new Button();
            btnVoltar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProd).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 18);
            label1.Name = "label1";
            label1.Size = new Size(107, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome Do Produto:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 79);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Preço:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 148);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 2;
            label3.Text = "Descrição:";
            // 
            // txtNomeProd
            // 
            txtNomeProd.Location = new Point(29, 36);
            txtNomeProd.Name = "txtNomeProd";
            txtNomeProd.Size = new Size(172, 23);
            txtNomeProd.TabIndex = 3;
            // 
            // txtPrecoProd
            // 
            txtPrecoProd.Location = new Point(29, 97);
            txtPrecoProd.Name = "txtPrecoProd";
            txtPrecoProd.Size = new Size(172, 23);
            txtPrecoProd.TabIndex = 4;
            // 
            // txtDescricaoProd
            // 
            txtDescricaoProd.Location = new Point(29, 166);
            txtDescricaoProd.Name = "txtDescricaoProd";
            txtDescricaoProd.Size = new Size(172, 23);
            txtDescricaoProd.TabIndex = 5;
            // 
            // dgvProd
            // 
            dgvProd.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProd.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dgvProd.Location = new Point(29, 230);
            dgvProd.Name = "dgvProd";
            dgvProd.Size = new Size(343, 150);
            dgvProd.TabIndex = 6;
            dgvProd.CellContentClick += dgvProd_CellContentClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "Nome";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Preço";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Descrição";
            Column3.Name = "Column3";
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(29, 201);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(75, 23);
            btnCadastrar.TabIndex = 7;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnAtualizar
            // 
            btnAtualizar.Location = new Point(110, 201);
            btnAtualizar.Name = "btnAtualizar";
            btnAtualizar.Size = new Size(75, 23);
            btnAtualizar.TabIndex = 8;
            btnAtualizar.Text = "Atualizar";
            btnAtualizar.UseVisualStyleBackColor = true;
            btnAtualizar.Click += btnAtualizar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(191, 201);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(75, 23);
            btnExcluir.TabIndex = 9;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnListar
            // 
            btnListar.Location = new Point(272, 201);
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(75, 23);
            btnListar.TabIndex = 10;
            btnListar.Text = "Listar";
            btnListar.UseVisualStyleBackColor = true;
            btnListar.Click += btnListar_Click;
            // 
            // btnLimparCamp
            // 
            btnLimparCamp.Location = new Point(135, 386);
            btnLimparCamp.Name = "btnLimparCamp";
            btnLimparCamp.Size = new Size(118, 23);
            btnLimparCamp.TabIndex = 11;
            btnLimparCamp.Text = "Limpar Campos";
            btnLimparCamp.UseVisualStyleBackColor = true;
            btnLimparCamp.Click += btnLimparCamp_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(297, 386);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(75, 23);
            btnVoltar.TabIndex = 12;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // frmProdutos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnVoltar);
            Controls.Add(btnLimparCamp);
            Controls.Add(btnListar);
            Controls.Add(btnExcluir);
            Controls.Add(btnAtualizar);
            Controls.Add(btnCadastrar);
            Controls.Add(dgvProd);
            Controls.Add(txtDescricaoProd);
            Controls.Add(txtPrecoProd);
            Controls.Add(txtNomeProd);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmProdutos";
            Text = "frmProdutos";
            ((System.ComponentModel.ISupportInitialize)dgvProd).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNomeProd;
        private TextBox txtPrecoProd;
        private TextBox txtDescricaoProd;
        private DataGridView dgvProd;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private Button btnCadastrar;
        private Button btnAtualizar;
        private Button btnExcluir;
        private Button btnListar;
        private Button btnLimparCamp;
        private Button btnVoltar;
    }
}