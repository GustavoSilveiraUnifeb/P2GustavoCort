﻿namespace p2
{
    partial class frmCadUsu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNomeUsu = new TextBox();
            txtSenha = new TextBox();
            txtNewSenha = new TextBox();
            btnCad = new Button();
            btnExc = new Button();
            btnAltSen = new Button();
            btnVoltar = new Button();
            dgvUsu = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvUsu).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 20);
            label1.Name = "label1";
            label1.Size = new Size(103, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome De Usuário:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 68);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 1;
            label2.Text = "Senha:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 121);
            label3.Name = "label3";
            label3.Size = new Size(73, 15);
            label3.TabIndex = 2;
            label3.Text = "Nova Senha:";
            // 
            // txtNomeUsu
            // 
            txtNomeUsu.Location = new Point(30, 38);
            txtNomeUsu.Name = "txtNomeUsu";
            txtNomeUsu.Size = new Size(100, 23);
            txtNomeUsu.TabIndex = 3;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(30, 86);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(100, 23);
            txtSenha.TabIndex = 4;
            // 
            // txtNewSenha
            // 
            txtNewSenha.Location = new Point(30, 139);
            txtNewSenha.Name = "txtNewSenha";
            txtNewSenha.Size = new Size(100, 23);
            txtNewSenha.TabIndex = 5;
            // 
            // btnCad
            // 
            btnCad.Location = new Point(164, 194);
            btnCad.Name = "btnCad";
            btnCad.Size = new Size(75, 23);
            btnCad.TabIndex = 7;
            btnCad.Text = "Cadastrar";
            btnCad.UseVisualStyleBackColor = true;
            btnCad.Click += btnCad_Click;
            // 
            // btnExc
            // 
            btnExc.Location = new Point(256, 194);
            btnExc.Name = "btnExc";
            btnExc.Size = new Size(75, 23);
            btnExc.TabIndex = 8;
            btnExc.Text = "Excluir";
            btnExc.UseVisualStyleBackColor = true;
            btnExc.Click += btnExc_Click;
            // 
            // btnAltSen
            // 
            btnAltSen.Location = new Point(350, 194);
            btnAltSen.Name = "btnAltSen";
            btnAltSen.Size = new Size(99, 23);
            btnAltSen.TabIndex = 9;
            btnAltSen.Text = "Alterar Senha";
            btnAltSen.UseVisualStyleBackColor = true;
            btnAltSen.Click += btnAltSen_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(350, 255);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(99, 23);
            btnVoltar.TabIndex = 10;
            btnVoltar.Text = "Votar";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // dgvUsu
            // 
            dgvUsu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsu.Location = new Point(164, 38);
            dgvUsu.Name = "dgvUsu";
            dgvUsu.Size = new Size(285, 150);
            dgvUsu.TabIndex = 11;
            dgvUsu.CellContentClick += dgvUsu_CellContentClick;
            // 
            // frmCadUsu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(512, 328);
            Controls.Add(dgvUsu);
            Controls.Add(btnVoltar);
            Controls.Add(btnAltSen);
            Controls.Add(btnExc);
            Controls.Add(btnCad);
            Controls.Add(txtNewSenha);
            Controls.Add(txtSenha);
            Controls.Add(txtNomeUsu);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmCadUsu";
            Text = "frmCadUsu";
            Load += frmCadUsu_Load;
            ((System.ComponentModel.ISupportInitialize)dgvUsu).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNomeUsu;
        private TextBox txtSenha;
        private TextBox txtNewSenha;
        private Button btnCad;
        private Button btnExc;
        private Button btnAltSen;
        private Button btnVoltar;
        private DataGridView dgvUsu;
    }
}