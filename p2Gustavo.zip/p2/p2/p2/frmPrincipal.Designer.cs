﻿namespace p2
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCadUsu = new Button();
            btnCadCliente = new Button();
            btnCadProduto = new Button();
            btnCadPed = new Button();
            btnVoltar = new Button();
            SuspendLayout();
            // 
            // btnCadUsu
            // 
            btnCadUsu.Location = new Point(12, 12);
            btnCadUsu.Name = "btnCadUsu";
            btnCadUsu.Size = new Size(151, 23);
            btnCadUsu.TabIndex = 0;
            btnCadUsu.Text = "Cadastro de Usuário";
            btnCadUsu.UseVisualStyleBackColor = true;
            btnCadUsu.Click += btnCadUsu_Click;
            // 
            // btnCadCliente
            // 
            btnCadCliente.Location = new Point(169, 12);
            btnCadCliente.Name = "btnCadCliente";
            btnCadCliente.Size = new Size(141, 23);
            btnCadCliente.TabIndex = 1;
            btnCadCliente.Text = "Cadastro de Cliente";
            btnCadCliente.UseVisualStyleBackColor = true;
            btnCadCliente.Click += btnCadCliente_Click;
            // 
            // btnCadProduto
            // 
            btnCadProduto.Location = new Point(12, 50);
            btnCadProduto.Name = "btnCadProduto";
            btnCadProduto.Size = new Size(151, 23);
            btnCadProduto.TabIndex = 2;
            btnCadProduto.Text = "Cadastro de Produto";
            btnCadProduto.UseVisualStyleBackColor = true;
            btnCadProduto.Click += btnCadProduto_Click;
            // 
            // btnCadPed
            // 
            btnCadPed.Location = new Point(169, 50);
            btnCadPed.Name = "btnCadPed";
            btnCadPed.Size = new Size(141, 23);
            btnCadPed.TabIndex = 3;
            btnCadPed.Text = "Cadastro de Pedidos";
            btnCadPed.UseVisualStyleBackColor = true;
            btnCadPed.Click += btnCadPed_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(97, 96);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(148, 23);
            btnVoltar.TabIndex = 4;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(330, 141);
            Controls.Add(btnVoltar);
            Controls.Add(btnCadPed);
            Controls.Add(btnCadProduto);
            Controls.Add(btnCadCliente);
            Controls.Add(btnCadUsu);
            Name = "frmPrincipal";
            Text = "frmPrincipal";
            ResumeLayout(false);
        }

        #endregion

        private Button btnCadUsu;
        private Button btnCadCliente;
        private Button btnCadProduto;
        private Button btnCadPed;
        private Button btnVoltar;
    }
}